#ifndef WIN_RESOURCE_H
#define WIN_RESOURCE_H

#warning "Deprecated Windows-API include!"

#endif
