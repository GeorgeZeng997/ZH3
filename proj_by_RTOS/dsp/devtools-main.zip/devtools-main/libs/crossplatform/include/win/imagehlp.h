#ifndef WIN_IMAGEHLP_H
#define WIN_IMAGEHLP_H

#warning "Deprecated Windows-API include!"

#endif
