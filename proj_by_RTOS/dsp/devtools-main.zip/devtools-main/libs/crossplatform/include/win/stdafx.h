#ifndef WIN_STDAFX_H
#define WIN_STDAFX_H

#warning "Deprecated Windows-API include!"

#endif
