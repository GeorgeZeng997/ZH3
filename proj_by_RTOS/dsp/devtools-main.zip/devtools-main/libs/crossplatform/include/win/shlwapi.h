#ifndef WIN_SHLWAPI_H
#define WIN_SHLWAPI_H

#warning "Deprecated Windows-API include!"

#endif
