#ifndef WIN_TCHAR_H
#define WIN_TCHAR_H

#warning "Deprecated Windows-API include!"

#endif
