#ifndef WIN_SDKDDKVER_H
#define WIN_SDKDDKVER_H

#warning "Deprecated Windows-API include!"

#endif
