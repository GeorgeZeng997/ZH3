#ifndef WIN_WINDOWS_H
#define WIN_WINDOWS_H

#warning "Deprecated Windows-API include!"

#endif
