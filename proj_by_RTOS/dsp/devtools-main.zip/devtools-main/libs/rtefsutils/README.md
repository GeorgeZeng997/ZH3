# What is this?

RteFsUtils library provides utility methods of filesystem-related operations
is a utility class and correspond:

## How is it structured?

- RteFsUtils class is a utility class with static methods for file operations.
- RteFileChangeWatchThread class provides monitoring for file change events.
  For the time being it is implemented only for Windows.

## How is it used?

The methods and classes are used by executables and other libraries that need file operations.
