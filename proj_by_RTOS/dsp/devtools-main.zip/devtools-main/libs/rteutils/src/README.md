# What is this?

TBD:

## How is it structured?

TBD:

## How is it used?

### Building

- Call CMake command `cmake --build . --target RteUtils`
  >**OR**
- Use native build command (**msbuild, make, ninja**)

### Compilation

TBD:

### Linking

TBD:

## How to build and run tests?

### Building Tests

- Call CMake command `cmake --build . --target RteUtilsUnitTests`
  >**OR**
- Build using native build command (**msbuild, make, ninja**)

### Running Tests

- Goto \<PATH\>..rteutils/test/\<Debug|Release\>
- Call `./RteUtilsUnitTests`
