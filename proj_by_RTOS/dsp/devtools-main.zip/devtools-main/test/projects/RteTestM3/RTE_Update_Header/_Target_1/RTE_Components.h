
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'RteTestM3_Rte_Update_Header' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "ARMCM3.h"

/* ARM::RteTest:ComponentLevel@0.0.1 */
#define COMPONENT_LEVEL 1
/* ARM::RteTest:GlobalLevel@0.0.2 */
#define GLOBAL_LEVEL 1

#define GLOBAL_TEST_LEVEL 1

#endif /* RTE_COMPONENTS_H */
