
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'RteTestM3' 
 * Target:  'Target 1' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* ARM::RteTest:GlobalLevel@0.0.2 */
#define GLOBAL_PRE_INCLUDE 1


#endif /* PRE_INCLUDE_GLOBAL_H */
