
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'RteTestM3' 
 * Target:  'Target 1' 
 */

#ifndef PRE_INCLUDE_RTETEST_COMPONENTLEVEL_H
#define PRE_INCLUDE_RTETEST_COMPONENTLEVEL_H

/* ARM::RteTest:ComponentLevel@0.0.1 */
#define LOCAL_PRE_INCLUDE 1

#endif /* PRE_INCLUDE_RTETEST_COMPONENTLEVEL_H */
