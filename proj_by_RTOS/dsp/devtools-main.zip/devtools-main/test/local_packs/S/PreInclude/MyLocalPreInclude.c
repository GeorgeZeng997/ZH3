#include "Outside/OutsideInclude.h"             // ARM::Other:GlobalLevel
#include "Include/RelativeInclude.h"    // ARM::Other:GlobalLevel

#ifdef MY_LOCAL_PRE_INCLUDE
  #warning local pre-include seen in component file
#endif
