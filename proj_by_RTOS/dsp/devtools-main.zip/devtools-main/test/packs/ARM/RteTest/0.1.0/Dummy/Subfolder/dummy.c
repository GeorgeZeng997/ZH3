
int Dummy2(int i) {
    return 1;
}
