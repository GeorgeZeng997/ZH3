
int Dummy1(int i) {
    return 1;
}
