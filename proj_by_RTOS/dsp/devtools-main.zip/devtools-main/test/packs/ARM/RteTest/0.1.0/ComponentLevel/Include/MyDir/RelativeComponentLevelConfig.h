#ifndef RelaitiveComponentLevelConfig_%Instance%
#define RelaitiveComponentLevelConfig_%Instance%

#define FILE_RelaitiveComponentLevelConfig_%Instance%

#endif // RelaitiveComponentLevelConfig.%Instance%
