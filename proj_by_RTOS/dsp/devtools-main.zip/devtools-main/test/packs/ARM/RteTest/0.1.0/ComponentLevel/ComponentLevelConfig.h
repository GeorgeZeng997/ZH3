#ifndef COMPONENT_LEVEL_CONFIG_H_%Instance%
#define COMPONENT_LEVEL_CONFIG_H_%Instance%

#define FILE_COMPONENT_LEVEL_CONFIG_%Instance%

#endif // COMPONENT_LEVEL_CONFIG_H_%Instance%
