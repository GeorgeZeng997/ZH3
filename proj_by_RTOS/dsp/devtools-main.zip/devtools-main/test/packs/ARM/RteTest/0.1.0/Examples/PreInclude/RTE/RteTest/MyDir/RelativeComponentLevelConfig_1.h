#ifndef RelaitiveComponentLevelConfig_1
#define RelaitiveComponentLevelConfig_1

#define FILE_RelaitiveComponentLevelConfig_1

#endif // RelaitiveComponentLevelConfig.1
